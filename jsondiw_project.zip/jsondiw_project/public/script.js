fetch('http://localhost:3000/produtos')
  .then(response => response.json())
  .then(data => {
    const lista = document.getElementById('produto-lista');
    data.forEach(produto => {
      const item = document.createElement('li');
      item.textContent = `${produto.nome} - R$ ${produto.preco.toFixed(2)}`;
      lista.appendChild(item);
    });
  })
  .catch(error => console.error('Erro ao carregar produtos:', error));